# Portable VoIP — architecture

## Trust and failure boundaries

```text
operator computer / USB                      target server
┌─────────────────────────┐   SSH/SCP       ┌──────────────────────────────┐
│ Tk launcher / CLI       │ ──────────────> │ systemd                     │
│ selected key stays here │  bundle + run   │ ├─ FreeSWITCH (SIP/RTP)     │
└─────────────────────────┘                 │ ├─ voip-panel (localhost)   │
                                            │ ├─ nginx (TLS/UI/API)        │
                                            │ ├─ nftables firewall         │
                                            │ └─ SQLite + local backups    │
                                            └──────────────────────────────┘
```

After installation the operator computer is not in the runtime path. GitHub,
Codex, Railway, DNS APIs and external HTTP services are not required. The
server still needs IP connectivity for SIP and RTP.

## Call path

1. FreeSWITCH accepts SIP only from enabled originator CIDRs.
2. The generated dialplan normalizes the destination, picks the longest
   enabled prefix and an enabled Originator → Terminator route.
3. Rating parameters are embedded in generated local XML/Lua artifacts.
4. FreeSWITCH originates to the terminator IP with its tech prefix.
5. JSON CDR is submitted only to `127.0.0.1`; a spool directory is retained for
   retry. No call-time request leaves the server.
6. The backend rates completed calls, writes immutable ledger operations and
   materialized balances in a single SQLite transaction.

The MVP generator produces deterministic FreeSWITCH ACL, gateway and dialplan
files. Reload is explicit and atomic: validate → write staging directory →
backup current generation → rename → `reloadxml`.

## Data model

`originators`, `originator_ips`, `terminators`, `destinations`, `prefixes`,
`routes`, `caller_id_pools`, `caller_id_numbers`, `rates`, `cdr`, `accounts`,
`ledger`, `settings`, `schema_migrations`.
Money is stored as integer micro-units (1 currency unit = 1,000,000) and call
duration as integer seconds. Billing cycles are restricted to `1/1`, `6/6`,
and `60/1`.

A route may reference one A-number pool. FreeSWITCH `mod_distributor` selects a
number locally using equal weight by default, sets both outbound Caller ID name
and number, and retains the original inbound Caller ID in a channel variable.
There is no call-time HTTP or cloud dependency.

## Deployment safety

- supported mobile target: fresh Ubuntu 24.04 LTS (Debian 12 is also accepted), systemd, root/sudo;
- preflight checks OS, disk, RAM, ports, sudo and clock before mutation;
- installer is idempotent and versioned;
- every mutation has a timestamped backup under `/var/backups/portable-voip`;
- rollback restores the last application/config/database snapshot;
- panel binds to loopback behind nginx; SSH and panel CIDRs are configurable;
- secrets are created on the server with mode `0600`; the SSH key is never read
  by the application nor copied into the bundle;
- SQLite uses WAL, foreign keys, busy timeout and periodic online backups.

## MVP limitations

The product is intentionally minimal. Before production traffic, validate the
generated SIP profile with the carrier, add a trusted TLS certificate, test
emergency routing/legal CDR retention, rehearse restore, and load-test rating.
The MVP has one administrator account and one active route per matched prefix;
multi-terminator failover is a later extension.

