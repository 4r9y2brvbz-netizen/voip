PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS originators (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS originator_ips (
  id INTEGER PRIMARY KEY,
  originator_id INTEGER NOT NULL REFERENCES originators(id) ON DELETE CASCADE,
  cidr TEXT NOT NULL,
  UNIQUE(originator_id, cidr)
);
CREATE TABLE IF NOT EXISTS terminators (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  host TEXT NOT NULL,
  tech_prefix TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS destinations (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1))
);
CREATE TABLE IF NOT EXISTS prefixes (
  id INTEGER PRIMARY KEY,
  destination_id INTEGER NOT NULL REFERENCES destinations(id) ON DELETE CASCADE,
  prefix TEXT NOT NULL UNIQUE CHECK(prefix NOT GLOB '*[^0-9]*')
);
CREATE TABLE IF NOT EXISTS caller_id_pools (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS caller_id_numbers (
  id INTEGER PRIMARY KEY,
  pool_id INTEGER NOT NULL REFERENCES caller_id_pools(id) ON DELETE CASCADE,
  number TEXT NOT NULL,
  weight INTEGER NOT NULL DEFAULT 1 CHECK(weight > 0),
  UNIQUE(pool_id, number)
);
CREATE TABLE IF NOT EXISTS routes (
  id INTEGER PRIMARY KEY,
  originator_id INTEGER NOT NULL REFERENCES originators(id) ON DELETE CASCADE,
  destination_id INTEGER NOT NULL REFERENCES destinations(id) ON DELETE CASCADE,
  terminator_id INTEGER NOT NULL REFERENCES terminators(id) ON DELETE RESTRICT,
  caller_id_pool_id INTEGER REFERENCES caller_id_pools(id) ON DELETE SET NULL,
  client_tech_prefix TEXT NOT NULL DEFAULT '',
  priority INTEGER NOT NULL DEFAULT 100,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  UNIQUE(originator_id, destination_id, priority)
);
CREATE TABLE IF NOT EXISTS rates (
  id INTEGER PRIMARY KEY,
  party_type TEXT NOT NULL CHECK(party_type IN ('originator','terminator')),
  party_id INTEGER NOT NULL,
  destination_id INTEGER NOT NULL REFERENCES destinations(id) ON DELETE CASCADE,
  price_micros INTEGER NOT NULL CHECK(price_micros >= 0),
  cycle TEXT NOT NULL CHECK(cycle IN ('1/1','6/6','60/1')),
  effective_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(party_type, party_id, destination_id, effective_at)
);
CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY,
  party_type TEXT NOT NULL CHECK(party_type IN ('originator','terminator')),
  party_id INTEGER NOT NULL,
  balance_micros INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'USD',
  UNIQUE(party_type, party_id)
);
CREATE TABLE IF NOT EXISTS ledger (
  id INTEGER PRIMARY KEY,
  account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
  amount_micros INTEGER NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('topup','adjustment','call_charge','call_cost')),
  reference TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(account_id, kind, reference)
);
CREATE TABLE IF NOT EXISTS cdr (
  id INTEGER PRIMARY KEY,
  uuid TEXT NOT NULL UNIQUE,
  originator_id INTEGER REFERENCES originators(id),
  terminator_id INTEGER REFERENCES terminators(id),
  destination_id INTEGER REFERENCES destinations(id),
  caller TEXT NOT NULL DEFAULT '',
  called TEXT NOT NULL,
  started_at TEXT NOT NULL,
  answered_at TEXT,
  ended_at TEXT NOT NULL,
  bill_seconds INTEGER NOT NULL DEFAULT 0 CHECK(bill_seconds >= 0),
  hangup_cause TEXT NOT NULL DEFAULT '',
  sell_micros INTEGER NOT NULL DEFAULT 0,
  buy_micros INTEGER NOT NULL DEFAULT 0,
  raw_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_cdr_called ON cdr(called);
CREATE INDEX IF NOT EXISTS idx_cdr_started ON cdr(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_prefix_longest ON prefixes(length(prefix) DESC, prefix);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT OR IGNORE INTO schema_migrations(version) VALUES (1);

