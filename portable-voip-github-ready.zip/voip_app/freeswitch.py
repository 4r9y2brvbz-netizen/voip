from __future__ import annotations

import html
import ipaddress
import os
import tempfile
from pathlib import Path
import sqlite3


def x(value: object) -> str:
    return html.escape(str(value), quote=True)


def generate(db: sqlite3.Connection) -> dict[str, str]:
    acls = db.execute("""SELECT o.id,o.name,oi.cidr FROM originators o JOIN originator_ips oi ON oi.originator_id=o.id WHERE o.enabled=1 ORDER BY o.id,oi.cidr""").fetchall()
    terminators = db.execute("SELECT * FROM terminators WHERE enabled=1 ORDER BY id").fetchall()
    routes = db.execute("""SELECT r.*,p.prefix,t.host,t.tech_prefix FROM routes r JOIN prefixes p ON p.destination_id=r.destination_id JOIN terminators t ON t.id=r.terminator_id WHERE r.enabled=1 AND t.enabled=1 ORDER BY length(p.prefix) DESC,r.priority""").fetchall()
    caller_ids = db.execute("""SELECT p.id pool_id,n.number,n.weight FROM caller_id_pools p
      JOIN caller_id_numbers n ON n.pool_id=p.id WHERE p.enabled=1 ORDER BY p.id,n.id""").fetchall()
    grouped: dict[int, list[sqlite3.Row]] = {}
    for row in acls:
        grouped.setdefault(int(row["id"]), []).append(row)
    acl_lists = []
    for originator_id, rows in grouped.items():
        nodes = "\n".join(f'      <node type="allow" cidr="{x(row["cidr"])}"/>' for row in rows)
        acl_lists.append(f'    <list name="portable-originator-{originator_id}" default="deny">\n{nodes}\n    </list>')
    acl_xml = f'''<configuration name="acl.conf" description="portable-voip generated ACL">
  <network-lists>\n{chr(10).join(acl_lists)}\n  </network-lists>
</configuration>'''
    gateways = "\n".join(f'''  <gateway name="term_{row['id']}">
    <param name="proxy" value="{x(row['host'])}"/>
    <param name="register" value="false"/>
  </gateway>''' for row in terminators)
    gateway_xml = f'<include>\n{gateways}\n</include>'
    caller_groups: dict[int, list[sqlite3.Row]] = {}
    for row in caller_ids:
        caller_groups.setdefault(int(row["pool_id"]), []).append(row)
    distributor_lists = []
    for pool_id, rows in caller_groups.items():
        nodes = "\n".join(f'      <node name="{x(row["number"])}" weight="{int(row["weight"])}"/>' for row in rows)
        distributor_lists.append(f'    <list name="portable-caller-{pool_id}">\n{nodes}\n    </list>')
    distributor_xml = f'''<configuration name="distributor.conf" description="portable-voip A-number pools">
  <lists>\n{chr(10).join(distributor_lists)}\n  </lists>
</configuration>'''
    extensions = []
    for row in routes:
        prefix = x(row["prefix"])
        dial = x(row["tech_prefix"])
        caller_actions = ""
        if row["caller_id_pool_id"] and int(row["caller_id_pool_id"]) in caller_groups:
            pool_id = int(row["caller_id_pool_id"])
            caller_actions = f'''        <action application="distributor" data="portable-caller-{pool_id}"/>
        <action application="set" data="origination_caller_id_number=${{DISTRIBUTOR}}"/>
        <action application="set" data="origination_caller_id_name=${{DISTRIBUTOR}}"/>
        <action application="set" data="portable_original_caller_id=${{caller_id_number}}"/>\n'''
        extensions.append(f'''  <extension name="route_{row['id']}">
    <condition field="destination_number" expression="^{prefix}(\\d*)$">
      <condition field="${{acl(${{network_addr}} portable-originator-{row['originator_id']})}}" expression="^true$">
        <action application="set" data="portable_originator_id={row['originator_id']}"/>
        <action application="set" data="portable_terminator_id={row['terminator_id']}"/>
{caller_actions.rstrip()}
        <action application="bridge" data="sofia/gateway/term_{row['terminator_id']}/{dial}${{destination_number}}"/>
      </condition>
    </condition>
  </extension>''')
    dialplan = '<include>\n<context name="public">\n' + "\n".join(extensions) + '\n</context>\n</include>'
    return {"acl.conf.xml": acl_xml, "gateways.xml": gateway_xml, "dialplan.xml": dialplan, "distributor.conf.xml": distributor_xml}


def write_atomic(files: dict[str, str], target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent, prefix=".generation-") as tmp:
        stage = Path(tmp)
        for name, content in files.items():
            path = stage / name
            path.write_text(content + "\n")
            os.chmod(path, 0o640)
        old = target.with_name(target.name + ".previous")
        if old.exists():
            for item in old.iterdir():
                item.unlink()
            old.rmdir()
        if target.exists():
            target.rename(old)
        stage.rename(target)
        os.chmod(target, 0o750)

