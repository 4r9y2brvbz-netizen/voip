#!/bin/sh
set -eu

ROOT=/opt/portable-voip
STATE=/var/lib/portable-voip
BACKUPS=/var/backups/portable-voip
RELEASE="$ROOT/releases/incoming"
STAMP=$(date -u +%Y%m%dT%H%M%SZ)

. /etc/os-release
case "$ID:$VERSION_ID" in
  ubuntu:24.04|debian:12) ;;
  *) echo "Supported systems: Ubuntu 24.04 LTS or Debian 12 (found $ID:$VERSION_ID)"; exit 24 ;;
esac

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends python3 nginx nftables sqlite3 curl ca-certificates

sh "$RELEASE/deploy/install-freeswitch-source.sh"

install -d -m 0750 -o root -g root "$ROOT/releases" "$BACKUPS"
install -d -m 0750 -o voipapp -g voipapp "$STATE" 2>/dev/null || {
  id voipapp >/dev/null 2>&1 || useradd --system --home "$STATE" --shell /usr/sbin/nologin voipapp
  install -d -m 0750 -o voipapp -g voipapp "$STATE"
}
usermod -a -G voipapp freeswitch

if [ -L "$ROOT/current" ]; then
  previous=$(readlink -f "$ROOT/current")
  printf '%s\n' "$previous" > "$BACKUPS/$STAMP.previous-release"
fi
if [ -f "$STATE/voip.db" ]; then
  sqlite3 "$STATE/voip.db" ".backup '$BACKUPS/$STAMP.db'"
fi

version_dir="$ROOT/releases/$STAMP"
mv "$RELEASE" "$version_dir"
ln -sfn "$version_dir" "$ROOT/current.new"
mv -Tf "$ROOT/current.new" "$ROOT/current"

if [ ! -f /etc/portable-voip.env ]; then
  umask 077
  admin_password=$(python3 -c 'import secrets; print(secrets.token_urlsafe(18))')
  printf 'PORTABLE_VOIP_ADMIN_PASSWORD=%s\n' "$admin_password" > /etc/portable-voip.env
  printf 'INITIAL_ADMIN_PASSWORD=%s\n' "$admin_password" > "$STATE/initial-credentials"
  chown voipapp:voipapp "$STATE/initial-credentials"
fi

install -m 0644 "$ROOT/current/deploy/portable-voip.service" /etc/systemd/system/portable-voip.service
install -m 0644 "$ROOT/current/deploy/portable-voip-backup.service" /etc/systemd/system/portable-voip-backup.service
install -m 0644 "$ROOT/current/deploy/portable-voip-backup.timer" /etc/systemd/system/portable-voip-backup.timer
install -m 0644 "$ROOT/current/deploy/freeswitch.service" /etc/systemd/system/freeswitch.service
install -m 0644 "$ROOT/current/deploy/nginx.conf" /etc/nginx/sites-available/portable-voip
ln -sfn /etc/nginx/sites-available/portable-voip /etc/nginx/sites-enabled/portable-voip
rm -f /etc/nginx/sites-enabled/default

install -m 0755 "$ROOT/current/deploy/backup.sh" /usr/local/sbin/portable-voip-backup
install -m 0755 "$ROOT/current/deploy/rollback.sh" /usr/local/sbin/portable-voip-rollback
install -m 0755 "$ROOT/current/deploy/diagnostics.sh" /usr/local/sbin/portable-voip-diagnostics
install -m 0644 "$ROOT/current/deploy/nftables.conf" /etc/nftables.conf

chown -R root:root "$version_dir"
chown -R voipapp:voipapp "$STATE"
systemctl daemon-reload
nginx -t
nft -c -f /etc/nftables.conf
systemctl enable --now nftables portable-voip portable-voip-backup.timer nginx freeswitch
systemctl restart portable-voip nginx
curl -fsS http://127.0.0.1:8088/api/health >/dev/null

PYTHONPATH="$ROOT/current" python3 - <<'PY'
from pathlib import Path
from voip_app.db import connect, init_db
from voip_app.freeswitch import generate, write_atomic
db_path = Path('/var/lib/portable-voip/voip.db')
with connect(db_path) as db:
    init_db(db)
    write_atomic(generate(db), Path('/var/lib/portable-voip/generated'))
PY
chown -R voipapp:voipapp "$STATE"
install -d -m 0755 /etc/freeswitch/sip_profiles/external /etc/freeswitch/dialplan/public
ln -sfn "$STATE/generated/acl.conf.xml" /etc/freeswitch/autoload_configs/portable-voip-acl.conf.xml
ln -sfn "$STATE/generated/distributor.conf.xml" /etc/freeswitch/autoload_configs/distributor.conf.xml
ln -sfn "$STATE/generated/gateways.xml" /etc/freeswitch/sip_profiles/external/portable-voip-gateways.xml
ln -sfn "$STATE/generated/dialplan.xml" /etc/freeswitch/dialplan/public/portable-voip.xml
if grep -q '<!-- *<load module="mod_distributor"/> *-->' /etc/freeswitch/autoload_configs/modules.conf.xml; then
  sed -i 's|<!-- *<load module="mod_distributor"/> *-->|<load module="mod_distributor"/>|' /etc/freeswitch/autoload_configs/modules.conf.xml
elif ! grep -q '<load module="mod_distributor"/>' /etc/freeswitch/autoload_configs/modules.conf.xml; then
  sed -i '/<\/modules>/i\\    <load module="mod_distributor"/>' /etc/freeswitch/autoload_configs/modules.conf.xml
fi
fs_cli -x reloadxml >/dev/null
fs_cli -x 'load mod_distributor' >/dev/null 2>&1 || fs_cli -x 'reload mod_distributor' >/dev/null
fs_cli -x 'distributor_ctl reload' >/dev/null
echo "INSTALL_OK release=$STAMP credentials=$STATE/initial-credentials"

