#!/bin/sh
set -eu
STATE=/var/lib/portable-voip
DEST=/var/backups/portable-voip
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
install -d -m 0750 "$DEST"
sqlite3 "$STATE/voip.db" ".backup '$DEST/$STAMP.db'"
tar -czf "$DEST/$STAMP-config.tgz" -C "$STATE" generated 2>/dev/null || true
find "$DEST" -type f -mtime +30 -delete

