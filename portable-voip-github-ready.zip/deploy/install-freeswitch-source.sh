#!/bin/sh
set -eu

FS_VERSION=v1.10.12
SOFIA_VERSION=v1.13.17
SPANDSP_VERSION=v3.1.1
SOURCE_ROOT=/usr/local/src/portable-voip-build
JOBS=${FREESWITCH_BUILD_JOBS:-1}

if command -v freeswitch >/dev/null 2>&1; then
  echo "FreeSWITCH is already installed"
  exit 0
fi

echo "Installing FreeSWITCH build dependencies"
apt-get update
apt-get install -y --no-install-recommends \
  build-essential autoconf automake libtool libtool-bin pkg-config cmake \
  curl ca-certificates bison yasm nasm \
  uuid-dev libpcre3-dev libedit-dev libsqlite3-dev libtiff-dev libjpeg-dev \
  libogg-dev libspeex-dev libspeexdsp-dev libssl-dev \
  libcurl4-openssl-dev zlib1g-dev libsndfile1-dev libopus-dev libldns-dev

# A one-thread build fits in 2 GB in most cases; swap protects small Droplets
# from an out-of-memory kill during the C/C++ compilation stage.
memory_kb=$(awk '/MemTotal:/ {print $2}' /proc/meminfo)
swap_kb=$(awk '/SwapTotal:/ {print $2}' /proc/meminfo)
if [ "${memory_kb:-0}" -lt 3145728 ] && [ "${swap_kb:-0}" -lt 1048576 ]; then
  echo "Creating a 4 GB build swap file"
  if ! fallocate -l 4G /swapfile 2>/dev/null; then
    dd if=/dev/zero of=/swapfile bs=1M count=4096 status=progress
  fi
  chmod 0600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  grep -q '^/swapfile ' /etc/fstab || printf '/swapfile none swap sw 0 0\n' >> /etc/fstab
fi

install -d -m 0755 "$SOURCE_ROOT"

echo "Building Sofia-SIP $SOFIA_VERSION"
if ! pkg-config --atleast-version=1.13.17 sofia-sip-ua 2>/dev/null; then
  rm -rf "$SOURCE_ROOT/sofia-sip-${SOFIA_VERSION#v}"
  curl --fail --location --retry 5 --retry-delay 3 \
    "https://github.com/freeswitch/sofia-sip/archive/refs/tags/$SOFIA_VERSION.tar.gz" \
    -o "$SOURCE_ROOT/sofia-sip.tar.gz"
  tar -xzf "$SOURCE_ROOT/sofia-sip.tar.gz" -C "$SOURCE_ROOT"
  cd "$SOURCE_ROOT/sofia-sip-${SOFIA_VERSION#v}"
  ./bootstrap.sh
  ./configure --prefix=/usr
  make -j"$JOBS"
  make install
  ldconfig
fi

echo "Building SpanDSP $SPANDSP_VERSION"
if ! pkg-config --atleast-version=3.0 spandsp 2>/dev/null; then
  rm -rf "$SOURCE_ROOT/spandsp-${SPANDSP_VERSION#v}"
  curl --fail --location --retry 5 --retry-delay 3 \
    "https://github.com/freeswitch/spandsp/archive/refs/tags/$SPANDSP_VERSION.tar.gz" \
    -o "$SOURCE_ROOT/spandsp.tar.gz"
  tar -xzf "$SOURCE_ROOT/spandsp.tar.gz" -C "$SOURCE_ROOT"
  cd "$SOURCE_ROOT/spandsp-${SPANDSP_VERSION#v}"
  ./bootstrap.sh
  ./configure --prefix=/usr
  make -j"$JOBS"
  make install
  ldconfig
fi

echo "Building FreeSWITCH $FS_VERSION (this can take 20-45 minutes)"
rm -rf "$SOURCE_ROOT/freeswitch-${FS_VERSION#v}"
curl --fail --location --retry 5 --retry-delay 3 \
  "https://github.com/signalwire/freeswitch/archive/refs/tags/$FS_VERSION.tar.gz" \
  -o "$SOURCE_ROOT/freeswitch.tar.gz"
tar -xzf "$SOURCE_ROOT/freeswitch.tar.gz" -C "$SOURCE_ROOT"
cd "$SOURCE_ROOT/freeswitch-${FS_VERSION#v}"

./bootstrap.sh -j

cat > modules.conf <<'EOF'
applications/mod_commands
applications/mod_db
applications/mod_directory
applications/mod_distributor
applications/mod_dptools
applications/mod_expr
applications/mod_fifo
applications/mod_hash
codecs/mod_g723_1
codecs/mod_g729
codecs/mod_opus
dialplans/mod_dialplan_xml
endpoints/mod_loopback
endpoints/mod_sofia
event_handlers/mod_cdr_csv
event_handlers/mod_cdr_sqlite
event_handlers/mod_event_socket
event_handlers/mod_json_cdr
event_handlers/mod_logfile
formats/mod_local_stream
formats/mod_native_file
formats/mod_sndfile
loggers/mod_console
loggers/mod_syslog
say/mod_say_en
timers/mod_posix_timer
xml_int/mod_xml_cdr
EOF

./configure -C --enable-portable-binary --disable-dependency-tracking \
  --prefix=/usr --localstatedir=/var --sysconfdir=/etc \
  --with-gnu-ld --with-openssl
make -j"$JOBS"
make install
ldconfig

id freeswitch >/dev/null 2>&1 || useradd --system --home /var/lib/freeswitch --shell /usr/sbin/nologin freeswitch
install -d -m 0750 -o freeswitch -g freeswitch \
  /var/lib/freeswitch /var/lib/freeswitch/db /var/log/freeswitch /run/freeswitch
chown -R freeswitch:freeswitch /etc/freeswitch /var/lib/freeswitch /var/log/freeswitch /run/freeswitch

echo "FreeSWITCH $FS_VERSION source build complete"
