import unittest
from pathlib import Path


ROOT = Path(__file__).parents[1]


class MobileDeployTests(unittest.TestCase):
    def test_cloud_init_remains_a_template(self):
        text = (ROOT / "cloud-init.example.yaml").read_text()
        self.assertTrue(text.startswith("#cloud-config"))
        self.assertIn("https://github.com/CHANGE-ME/", text)
        self.assertIn('SIGNALWIRE_TOKEN="CHANGE-ME"', text)

    def test_bootstrap_has_no_embedded_credentials(self):
        text = (ROOT / "bootstrap.sh").read_text()
        self.assertIn("${SIGNALWIRE_TOKEN:?", text)
        self.assertNotIn("PRIVATE KEY", text)
        self.assertIn("/var/lib/portable-voip-install.status", text)

