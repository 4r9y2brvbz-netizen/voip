import os
import tempfile
import unittest
from pathlib import Path
from deployer.core import Target, make_bundle, plan

class DeployerTests(unittest.TestCase):
    def test_plan_and_secret_free_bundle(self):
        with tempfile.TemporaryDirectory() as d:
            key=Path(d)/"id"; key.write_text("not-a-real-key"); os.chmod(key,0o600)
            target=Target("203.0.113.10","root",key)
            self.assertIn("idempotent",plan(target))
            output=Path(d)/"bundle.tgz"; make_bundle(Path(__file__).parents[1],output)
            self.assertTrue(output.is_file())
            self.assertNotIn(str(key),output.read_bytes().decode("latin1",errors="ignore"))

