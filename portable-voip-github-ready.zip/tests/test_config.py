import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from voip_app.db import connect, init_db, seed_demo, validate_cidr
from voip_app.freeswitch import generate, write_atomic

class ConfigTests(unittest.TestCase):
    def test_validation_and_generation(self):
        with tempfile.TemporaryDirectory() as d:
            db=connect(Path(d)/"db"); init_db(db); seed_demo(db); files=generate(db)
            self.assertEqual(validate_cidr("198.51.100.10"),"198.51.100.10/32")
            self.assertIn('cidr="198.51.100.10/32"',files["acl.conf.xml"])
            self.assertIn('portable-originator-1',files["acl.conf.xml"])
            self.assertIn('term_1',files["gateways.xml"])
            for content in files.values():
                ET.fromstring(content)
            target=Path(d)/"generated"; write_atomic(files,target)
            self.assertEqual(set(p.name for p in target.iterdir()),set(files))
            self.assertIn("distributor.conf.xml", files)
            db.close()

