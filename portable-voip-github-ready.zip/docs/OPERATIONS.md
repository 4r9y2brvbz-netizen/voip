# Operations

## Service and credentials

The panel listens on `127.0.0.1:8088` and nginx exposes it. Initial credentials
are written once to `/var/lib/portable-voip/initial-credentials` with restricted
permissions. Remove that file after changing the password.

```bash
systemctl status portable-voip freeswitch nginx nftables
portable-voip-diagnostics > /tmp/portable-voip-diagnostics.txt
```

## Backup and restore

Daily online SQLite backups and config archives live under
`/var/backups/portable-voip` and are retained for 30 days. Create one manually:

```bash
sudo portable-voip-backup
```

`sudo portable-voip-rollback` restores the last release pointer and most recent
database snapshot, then verifies health. Always take an extra off-server,
encrypted copy before upgrades.

## Configuration activation

The panel's System page previews generated ACL, gateways and dialplan. Activation
writes a complete generation atomically under `/var/lib/portable-voip/generated`.
For MVP safety, an operator must inspect and copy/include those files into the
distribution-specific FreeSWITCH config tree, run `fs_cli -x 'reloadxml'`, and
place a test call. The installer does not overwrite distribution SIP profiles.

## CDR export

Use the CDR search in the panel for quick review. For a full offline export:

```bash
sqlite3 -header -csv /var/lib/portable-voip/voip.db 'select * from cdr order by started_at;' > cdr.csv
```

