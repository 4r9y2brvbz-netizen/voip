# Portable VoIP Deployer

An autonomous, deliberately small wholesale VoIP platform. A local launcher
checks a new server over SSH and installs FreeSWITCH, a local management panel,
SQLite billing, firewall rules, backups and diagnostics. No real deployment is
performed by the test suite or by opening the launcher.

Route features include per-originator ACLs, buy/sell rating, tech prefixes and
optional A-number pools with local weighted rotation inside FreeSWITCH.

## Deploy from an iPhone

For the GitHub → DigitalOcean Ubuntu 24.04 LTS Droplet workflow, follow
[MOBILE_DEPLOY.md](MOBILE_DEPLOY.md). The first-boot installer downloads this
repository and installs FreeSWITCH plus the complete local runtime. Do not use
DigitalOcean App Platform for SIP/RTP.

## Local demo (safe; no SSH)

Requires Python 3.11+ and no third-party packages.

```bash
cd portable-voip-deployer
python3 -m voip_app --db /tmp/portable-voip-demo.db --init-demo --port 8088
```

Open `http://127.0.0.1:8088`. Demo login: `admin` / `change-me-now`. Change it
immediately if the process is exposed beyond localhost.

Run checks:

```bash
python3 -m unittest discover -s tests -v
python3 -m deployer.cli plan --host 203.0.113.10 --user root --key /path/to/key
```

`plan` performs no network connection. For a real server, first use `preflight`;
only the explicit `deploy` command changes it:

```bash
python3 -m deployer.cli preflight --host SERVER_IP --user root --key /path/to/key
python3 -m deployer.cli deploy --host SERVER_IP --user root --key /path/to/key
```

Or launch the portable GUI:

```bash
python3 launcher.py
```

The GUI always shows the plan and requires an explicit confirmation before
deployment. This repository never stores the selected private key.

## First production checklist

1. Use a fresh supported server and a non-root SSH user with passwordless sudo.
2. Restrict panel access to an administrator CIDR.
3. Run preflight and inspect every warning.
4. Deploy, open the panel, replace the generated administrator password.
5. Add originators, terminators, prefixes, routes and both buy/sell rates.
6. Generate configuration, inspect the diff, then activate/reload FreeSWITCH.
7. Place test calls in both directions and verify CDR, cycles and both ledgers.
8. Create a backup and perform a restore rehearsal before live traffic.

See [ARCHITECTURE.md](ARCHITECTURE.md), [docs/OPERATIONS.md](docs/OPERATIONS.md)
and [docs/SECURITY.md](docs/SECURITY.md).

