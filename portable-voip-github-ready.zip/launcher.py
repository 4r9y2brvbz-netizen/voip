from __future__ import annotations

import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from deployer.core import Target, deploy, plan, preflight


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Portable VoIP Deployer")
        self.geometry("760x560")
        self.resizable(True, True)
        self.host = tk.StringVar()
        self.user = tk.StringVar(value="root")
        self.key = tk.StringVar()
        self.port = tk.IntVar(value=22)
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self._build()
        self.after(150, self._poll)

    def _build(self) -> None:
        shell = ttk.Frame(self, padding=24)
        shell.pack(fill="both", expand=True)
        ttk.Label(shell, text="Portable VoIP", font=("Helvetica", 24, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(shell, text="Install an autonomous routing and billing node over SSH.").grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 20))
        fields = [("Server IP", self.host), ("SSH user", self.user), ("SSH port", self.port)]
        for row, (label, variable) in enumerate(fields, start=2):
            ttk.Label(shell, text=label).grid(row=row, column=0, sticky="w", pady=6)
            ttk.Entry(shell, textvariable=variable).grid(row=row, column=1, columnspan=2, sticky="ew", pady=6)
        ttk.Label(shell, text="Private key").grid(row=5, column=0, sticky="w", pady=6)
        ttk.Entry(shell, textvariable=self.key).grid(row=5, column=1, sticky="ew", pady=6)
        ttk.Button(shell, text="Choose…", command=self._choose).grid(row=5, column=2, padx=(8, 0))
        actions = ttk.Frame(shell)
        actions.grid(row=6, column=0, columnspan=3, sticky="ew", pady=16)
        ttk.Button(actions, text="Show plan", command=self._show_plan).pack(side="left")
        ttk.Button(actions, text="Run preflight", command=lambda: self._run("preflight")).pack(side="left", padx=8)
        ttk.Button(actions, text="Deploy", command=self._confirm_deploy).pack(side="left")
        self.log = tk.Text(shell, height=18, wrap="word", bg="#101418", fg="#d7e2ea", insertbackground="white")
        self.log.grid(row=7, column=0, columnspan=3, sticky="nsew")
        shell.columnconfigure(1, weight=1)
        shell.rowconfigure(7, weight=1)

    def _target(self) -> Target:
        return Target(self.host.get().strip(), self.user.get().strip(), Path(self.key.get()).expanduser(), int(self.port.get()))

    def _choose(self) -> None:
        selected = filedialog.askopenfilename(title="Select private SSH key")
        if selected:
            self.key.set(selected)

    def _show_plan(self) -> None:
        try:
            self._write(plan(self._target()))
        except Exception as exc:
            messagebox.showerror("Invalid target", str(exc))

    def _confirm_deploy(self) -> None:
        self._show_plan()
        if messagebox.askyesno("Confirm server change", "Deploy to this server now? A backup is created before activation."):
            self._run("deploy")

    def _run(self, action: str) -> None:
        try:
            target = self._target()
            target.validate()
        except Exception as exc:
            messagebox.showerror("Invalid target", str(exc))
            return
        self._write(f"\nStarting {action}…\n")
        def worker() -> None:
            try:
                result = preflight(target) if action == "preflight" else deploy(target, Path(__file__).parent)
                self.events.put(("done", result))
            except Exception as exc:
                self.events.put(("error", exc))
        threading.Thread(target=worker, daemon=True).start()

    def _poll(self) -> None:
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "done":
                    self._write(value.stdout + value.stderr + f"\nExit code: {value.returncode}\n")
                else:
                    self._write(f"Error: {value}\n")
        except queue.Empty:
            pass
        self.after(150, self._poll)

    def _write(self, text: str) -> None:
        self.log.insert("end", text + ("\n" if not text.endswith("\n") else ""))
        self.log.see("end")


if __name__ == "__main__":
    Launcher().mainloop()
