# Install from an iPhone: GitHub → DigitalOcean Droplet

This path installs the complete runtime on one new server. Do **not** choose
DigitalOcean App Platform: SIP/RTP, persistent SQLite and system services need a
Droplet.

## Before starting

1. Create a free SignalWire account and a Personal Access Token for the official
   FreeSWITCH package repository. Keep it private.
2. Create a **public** GitHub repository and upload every file from this folder.
   Do not add the SignalWire token, SSH keys or SIP credentials to GitHub.
3. In GitHub, open `cloud-init.example.yaml`, tap Edit, and replace:
   - `CHANGE-ME` in `REPO_URL` with the GitHub owner/repository;
   - `CHANGE-ME` in `SIGNALWIRE_TOKEN` with the SignalWire token.
   Copy the entire edited file, then discard the edit — never commit the token.

## Create the server

In the DigitalOcean mobile website:

1. Tap **Create → Droplets**.
2. Choose **Ubuntu 24.04 LTS x64** and at least **2 GB RAM / 1 vCPU**. Two vCPUs are
   preferable for production traffic.
3. Select an SSH key, enable monitoring and backups.
4. Open **Advanced Options → Startup scripts** and paste the edited cloud-init.
5. Create the Droplet. Installation normally takes several minutes.

The script clones the repository, configures the official FreeSWITCH repository,
installs FreeSWITCH and the local panel, then enables nginx, nftables, backups
and all systemd services. The SignalWire APT credential and copies in cloud-init
state are replaced after installation. For maximum safety, revoke that token in
SignalWire after the status becomes `READY`.

## Open and verify

Open the Droplet's public IP in Safari. Installation status is available through
the DigitalOcean Recovery Console:

```text
cat /var/lib/portable-voip-install.status
cat /var/log/portable-voip-install.log
cat /var/lib/portable-voip/initial-credentials
```

The expected status starts with `READY`. The last command shows the initial panel
password. Remove `initial-credentials` after changing the password.

## Security before calls

- Add HTTPS before entering production data.
- Restrict SSH and panel access in DigitalOcean Cloud Firewall.
- Replace the broad SIP firewall rules with the exact originator/terminator IPs.
- Test one call, RTP in both directions, CDR rating, balances and restore.
- Never commit tokens, private keys or SIP credentials to GitHub.

